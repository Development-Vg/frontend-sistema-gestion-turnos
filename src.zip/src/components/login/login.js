import React from 'react';
import './login.css';
import { Container } from 'react-bootstrap';

import Form from 'react-bootstrap/Form';


import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';


import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';




const LoginForm = () => {
    const handleLogin = (event) => {
        event.preventDefault();
        // Lógica para iniciar sesión
    };

    return (
        <div className="wrapper fadeInDown">
            <Container className="main">
                <Row className="custom-row">
                    <Col md={6} className="image"></Col>
                    <Col md={6} className="right">
                        <div className="input-box">
                            <h1>RESERVAS</h1>
                            <Form onSubmit={handleLogin}>
                                <Form.Group className="input-field" controlId="username">
                                    <Form.Control type="text" className="input" placeholder="Usuario" required autoComplete="off" />
                                    <Form.Label>Usuario</Form.Label>
                                </Form.Group>
                                <Form.Group className="input-field" controlId="password">
                                    <Form.Control type="password" className="input" placeholder="Contraseña" required />
                                    <Form.Label>Contraseña</Form.Label>
                                </Form.Group>
                                <div className="input-field">
                                    <Button type="submit" className="submit">Iniciar sesión</Button>
                                </div>
                            </Form>
                            <div className="signin">
                                <span>¿Olvidaste tu contraseña? <a href="#">Recuperar contraseña</a></span><br/><br/>
                                <span>¿No tienes una cuenta? <a href="#" >Regístrate</a></span>   
                                {/* MOADAL LLAMAR  */}
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};


function ModalRegister() {
    return (
        <div
            className="modal show"
            style={{ display: 'block', position: 'initial' }}
        >
            <Modal.Dialog>

                <Modal.Header closeButton>
                    <Modal.Title>Registro Usuario</Modal.Title>
                </Modal.Header>

                <Modal.Body>
                    <Form>

                        {/* <Form.Group className="mb-3" controlId="formBasicEmail"> 
                            <Form.Label>Email address</Form.Label>
                            <Form.Control type="email" placeholder="Enter email" />
                            <Form.Text className="text-muted">
                                We'll never share your email with anyone else.
                            </Form.Text>
                        </Form.Group>*/}


                        <Row>
                            {/* nombre */}
                            <div className="group col-6 mb-4">
                                <Form.Group controlId="nombre">
                                <Form.Label>Nombre</Form.Label>
                                    <Form.Control type="text" placeholder=" " />
                                    
                                </Form.Group>
                            </div>

                            <Col xs={6} className='group mb-4'>
                                <Form.Group controlId="apellido">
                                <Form.Label>Apellido</Form.Label>
                                    <Form.Control type="text" placeholder=" "  />
                                </Form.Group>
                            </Col>

                            <Col xs={12} className="group mb-4">
                            <Form.Label>Tipo de Documento</Form.Label>
                                <Form.Select id="tipo_documento" >
                                    <option value="">Seleccionar</option>
                                    <option value="CC">Cédula de Ciudadanía</option>
                                    <option value="CE">Cédula de Extranjería</option>
                                </Form.Select>
                                
                            </Col>
                            <Col xs={12} className='group mb-4'>
                            <Form.Label>Numero de Documento</Form.Label>
                                <Form.Group controlId="numero_documento">
                                    <Form.Control type="text" placeholder=""  required autoComplete="off" />
                                </Form.Group>

                            </Col>

                            <Col xs={12} className='group mb-4'>
                            <Form.Label>Numero de celular</Form.Label>
                                <Form.Group controlId="numero_celular">
                                    <Form.Control type="text" placeholder=""  required autoComplete="off" />
    
                                </Form.Group>
                            </Col>


                            <Col xs={12} className='group mb-4'>
                            <Form.Label>Correo electronico</Form.Label>
                                <Form.Group controlId="correo_electronico">
                                    <Form.Control type="email" placeholder=""  required />
                                    
                                </Form.Group>
                            </Col>

                            <Col xs={12} className='group mb-4'>
                            <Form.Label>Direccion de localdiad</Form.Label>
                                <Form.Group controlId="Direccion">
                                    <Form.Control type="text" placeholder="" />
                                </Form.Group>
                            </Col>

                            <Col xs={6} className='group mb-4'>
                            <Form.Label>Contraseña</Form.Label>
                                <Form.Group controlId="password">
                                    <Form.Control type="password" placeholder=""  required autoComplete="off" />
                                </Form.Group>
                            </Col>

                            <Col xs={6} className='group mb-4'>
                            <Form.Label>Validación contraseña</Form.Label>
                                <Form.Group controlId="vali_password">
                                    <Form.Control type="password" placeholder=""  required />
                                </Form.Group>
                            </Col>
                        </Row>

                    </Form>


                </Modal.Body>

                <Modal.Footer>
                    <Button variant="secondary">Close</Button>
                    <Button variant="primary">Save changes</Button>
                </Modal.Footer>
            </Modal.Dialog>
        </div>
    );
}

//export default ModalRegister;


 export default  LoginForm;
